"""Compact checked SIQS stores and replayable progress; no matrix dumps."""

import hashlib
import json
from dataclasses import asdict
from functools import partial

from ..common import arithmetic, utils
from .assignment_stream import assignment_identity
from .extraction import DependencyExtractor, prepare_relations
from .families import (
    PolynomialFamily,
    _checked_resources,
    _checksum,
    _identity,
)
from .linear_algebra import DependencySolver, filter_matrix
from .pipeline import QSJob
from .polynomial import Polynomial, polynomial_roots
from .relations import (
    AtomicRelation,
    CombinedRelation,
    _combination_workspace,
    combined_storage_reserve,
    verify_atomic,
    verify_combined,
)
from .sieve_collector import (
    DoubleLargeSieveConfig,
    GrowingDoubleLargeSieveConfig,
    SieveCollector,
    SieveConfig,
)
from .storage import require_published

VERSION = 3
MAX_BLOB_BYTES = 64 * 1024 * 1024


def _solver_digest(solver, *, encoding="decimal-v1"):
    """Retain legacy fingerprints; new masks use bounded hexadecimal text."""
    state = [
        solver.next_row,
        solver.xors,
        solver.pending,
        sorted(solver.pivots.items()),
        solver.dependencies,
    ]
    if encoding == "hex-v1":
        digest = hashlib.sha256()

        def feed(value):
            if arithmetic.is_integer(value):
                digest.update(('"' + hex(value) + '"').encode())
            elif value is None:
                digest.update(b"null")
            else:
                digest.update(b"[")
                for index, item in enumerate(value):
                    if index:
                        digest.update(b",")
                    feed(item)
                digest.update(b"]")

        feed(state)
        return digest.hexdigest()

    if encoding != "decimal-v1":
        raise ValueError("unknown SIQS solver digest encoding")
    return _checksum(state)


def _store(collector):
    require_published(collector)
    if collector._graph is not None:
        from .large_prime_checkpoint import pack_store

        return pack_store(collector)
    atoms = list(collector._atoms.values())
    indices = {atom.relation_id: i for i, atom in enumerate(atoms)}
    polynomials, lookup, encoded = [], {}, []

    for atom in atoms:
        key = (
            atom.polynomial.a,
            atom.polynomial.b,
            atom.polynomial.square_coefficient,
        )
        if key not in lookup:
            lookup[key] = len(polynomials)
            polynomials.append(key)
        encoded.append(
            [
                lookup[key],
                atom.position,
                atom.sign,
                atom.exponents,
                atom.residual,
            ]
        )

    combined = [
        [
            tuple(indices[i] for i in item.atom_ids),
            item.u,
            item.sign,
            item.exponents,
            item.square_correction,
        ]
        for item in collector._combined
    ]
    rows = collector._full + collector._combined
    # Solver masks use mixed admission order, while storage encodes full
    # and combined payloads separately. Retain the mapping between them.
    row_indices = {id(row): index for index, row in enumerate(rows)}
    return dict(
        row_order=[row_indices[id(row)] for row in collector._rows],
        polynomials=polynomials,
        atoms=encoded,
        full=[indices[item.relation_id] for item in collector._full],
        combined=combined,
        pending=[[r, indices[i]] for r, i in collector._pending.items()],
    )


def _reserve_growing_checkpoint(job):
    """Reserve uncapped encoding before allocation, including scratch.

    Finite checkpoint quotas already reserve eight coexisting representations
    in SIQS metadata. With no byte quota, estimate from the actual live store
    instead; an explicit total-memory cap still applies to the snapshot.
    """
    collector = None if job.engine is None else job.engine.collector
    # Like legacy snapshots, emergency encoding may follow a stopped budget.
    # Its elapsed wall/CPU time is included in the resources captured at the
    # end of pack_job; restore separately charges verification/replay work.
    if job.config.checkpoint_bytes is not None:
        return
    encoded_bound = 65536
    if collector is not None:
        for atom in collector._atoms.values():
            encoded_bound += 2048 + 128 * len(atom.exponents)
            encoded_bound += 8 * (
                atom.polynomial.a.bit_length()
                + abs(atom.polynomial.b).bit_length()
                + abs(atom.position).bit_length()
            )
        for row in collector._combined:
            encoded_bound += 2048 + 128 * (
                len(row.atom_ids) + len(row.exponents)
            )
        live = (
            collector._workspace
            + job.config.memory_limit
            - job.engine.config.memory_limit
        )
        # A pause may retain preparation and elimination alongside the store.
        # Their existing reservations include solver fill-in and scratch;
        # releasing them for an earlier solve must not impose a later cap.
        if job.engine.prepared is not None:
            live += (
                job.engine.prepared.workspace_bytes
                - job.engine.prepared.shared_workspace_bytes
            )
        if job.engine.solver is not None:
            live += job.engine.solver.matrix.workspace_bytes
    else:
        live = job.config.metadata_reserve
    if live + 8 * encoded_bound > job.config.memory_limit:
        raise MemoryError("growing checkpoint encoding exceeds memory_bytes")


def pack_job(job):
    """Snapshot immutable provenance once, with bounded encoded output."""
    version = (
        7
        if job.config.sign_policy != "canonical"
        or job.config.collector.sparse_queue_bytes
        else 6
        if job.config.solve_policy != "window"
        else 5
        if isinstance(job.config.collector, GrowingDoubleLargeSieveConfig)
        else 4
        if isinstance(job.config.collector, DoubleLargeSieveConfig)
        else VERSION
    )
    if isinstance(job.config.collector, GrowingDoubleLargeSieveConfig):
        _reserve_growing_checkpoint(job)
    engine = job.engine
    store = _store(engine.collector) if engine is not None else None
    progress = None
    if engine is not None:
        solver = engine.solver
        progress = dict(
            polynomial=[
                engine.collector.polynomial.a,
                engine.collector.polynomial.b,
                engine.collector.polynomial.square_coefficient,
            ],
            lo=engine.lo,
            hi=engine.hi,
            next_position=engine.next_position,
            final_solve_done=engine.final_solve_done,
            storage_reason=engine.storage_reason,
            storage_solve_done=engine.storage_solve_done,
            last_count=engine.last_count,
            last_solved_count=engine.last_solved_count,
            stats=engine.stats,
            workspace_peak=engine._workspace_peak,
            solver=None
            if solver is None
            else dict(
                actions=solver.next_row + solver.xors,
                digest=_solver_digest(solver, encoding="hex-v1"),
                digest_encoding="hex-v1",
                pending=solver.pending is not None,
                extract_index=None
                if engine.extractor is None
                else engine.extractor.next_dependency,
            ),
        )
        if version >= 6:
            progress["zero_checked_count"] = engine.zero_checked_count

    payload = dict(
        version=version,
        backend=arithmetic.get_backend(job.config.backend).identity,
        n=job.n,
        seed=job.seed,
        config=asdict(job.config),
        multiplier=job.multiplier,
        base_identity=None if job.base is None else _identity(job.base),
        assignment_identity=None
        if job.assignments is None
        else assignment_identity(job.assignments),
        family_index=job.family_index,
        coefficient_cursor=job.coefficient_cursor,
        gray_index=None if job.family is None else job.family.next_index,
        pending=None
        if job.pending_step is None
        else [
            job.pending_step[0].a,
            job.pending_step[0].b,
            job.pending_step[0].square_coefficient,
        ],
        epoch=job.epoch,
        half_width=job.half_width,
        stalled=job.stalled,
        active=job.active,
        seen=sorted(job.seen),
        finished_reason=job.finished_reason,
        divisor=job.divisor,
        poly_start_rows=job.poly_start_rows,
        stats=job.stats,
        engine=progress,
        store=store,
        store_identity=_checksum(store),
    )
    if version >= 6:
        payload["pending_final_reason"] = job.pending_final_reason
    else:
        # Keep legacy checkpoint configuration and schema identities intact.
        payload["config"].pop("solve_policy")
    if version < 7:
        payload["config"].pop("sign_policy")
        payload["config"]["collector"].pop("sparse_queue_bytes")
    encoder = json.JSONEncoder(
        default=arithmetic.json_integer, sort_keys=True, separators=(",", ":")
    )
    parts, size = [], 0
    for part in encoder.iterencode(payload):
        size += len(part.encode())
        if size + 1024 > job.config.checkpoint_limit:
            raise MemoryError("full SIQS checkpoint exceeds checkpoint_bytes")
        parts.append(part)

    blob = "".join(parts)
    digest = hashlib.sha256(blob.encode()).hexdigest()
    resources = _checked_resources(
        dict(
            work_used=job.budget.used,
            wall_used=job.budget.wall_used,
            cpu_used=job.budget.cpu_used,
        )
    )
    return dict(
        version=version,
        blob=blob,
        sha256=digest,
        resources=resources,
        resources_sha256=_checksum(resources),
    )


def _restore_store(payload, collector, budget):
    """Reserve decoded provenance and verify every atom/combination afresh."""
    if collector._graph is not None:
        from .large_prime_checkpoint import restore_store

        return restore_store(payload, collector, budget)
    if not isinstance(payload, dict) or set(payload) - {"row_order"} != {
        "polynomials",
        "atoms",
        "full",
        "combined",
        "pending",
    }:
        raise ValueError("invalid SIQS relation store shape")

    config, base = collector.config, collector.factor_base

    for name, limit in (
        ("polynomials", config.max_atoms),
        ("atoms", config.max_atoms),
        ("full", config.max_relations),
        ("combined", config.max_relations),
        ("pending", config.max_partials),
    ):
        if not isinstance(payload[name], list) or len(payload[name]) > limit:
            raise ValueError("SIQS checkpoint store exceeds its cap")

    if len(payload["full"]) + len(payload["combined"]) > config.max_relations:
        raise ValueError("SIQS checkpoint relation cap exceeded")
    row_count = len(payload["full"]) + len(payload["combined"])
    order = (
        payload["row_order"]
        if "row_order" in payload
        else list(range(row_count))
    )
    if not isinstance(order, list) or len(order) != row_count:
        raise ValueError("invalid checkpoint mixed row order")
    for index in order:
        utils.require_integer(index, "matrix row index", 0)
        if index >= row_count:
            raise ValueError("checkpoint row order refers outside store")
    if len(set(order)) != row_count:
        raise ValueError("checkpoint row order repeats a row")
    reserves = []

    for record in payload["atoms"]:
        if not isinstance(record, list) or len(record) != 5:
            raise ValueError("invalid SIQS checkpoint atom")
        _, position, _, exponents, _ = record
        utils.require_integer(position, "position")
        if (
            abs(position).bit_length() > 4096
            or not isinstance(exponents, list)
            or len(exponents) > len(base.entries)
        ):
            raise ValueError("checkpoint atom size exceeds its bound")

        reserves.append(
            4096
            + 256 * len(exponents)
            + 16 * (abs(position).bit_length() + base.n_prime.bit_length())
        )

    combined_reserve = 0

    for record in payload["combined"]:
        if not isinstance(record, list) or len(record) != 5:
            raise ValueError("invalid checkpoint match")
        indices = record[0]
        if not isinstance(indices, list) or len(indices) != 2:
            raise ValueError("checkpoint match needs two atoms")
        for index in indices:
            utils.require_integer(index, "atom index", 0)
            if index >= len(payload["atoms"]):
                raise ValueError("missing checkpoint provenance")
        combined_reserve += combined_storage_reserve(
            sum(len(payload["atoms"][i][3]) for i in indices),
            base.n.bit_length(),
        )

    retained_workspace = (
        collector._workspace + sum(reserves) + combined_reserve
    )
    if retained_workspace > config.memory_limit:
        raise MemoryError("restored SIQS store exceeds memory_bytes")
    polynomials = [
        Polynomial(base.n, base.multiplier, *values)
        for values in payload["polynomials"]
    ]
    if len(set(p.identity for p in polynomials)) != len(polynomials):
        raise ValueError("duplicate checkpoint polynomial")
    atoms = []

    for index, (poly_index, position, sign, exponents, residual) in enumerate(
        payload["atoms"]
    ):
        utils.require_integer(poly_index, "polynomial index", 0)
        if poly_index >= len(polynomials):
            raise ValueError("checkpoint atom polynomial is missing")
        atom = AtomicRelation(
            polynomials[poly_index],
            position,
            sign,
            tuple(tuple(pair) for pair in exponents),
            residual,
        )
        verify_atomic(
            atom, base, residual_bound=config.residual_bound, budget=budget
        )
        if atom.relation_id in collector._atoms:
            raise ValueError("duplicate checkpoint atomic identity")
        collector._atoms[atom.relation_id] = atom
        collector._atom_bytes[atom.relation_id] = reserves[index]
        atoms.append(atom)

    used = set()

    def take(index):
        utils.require_integer(index, "atom index", 0)
        if index >= len(atoms) or index in used:
            raise ValueError("missing or reused checkpoint provenance")
        used.add(index)
        return atoms[index]

    for index in payload["full"]:
        atom = take(index)
        if atom.residual != 1:
            raise ValueError("partial checkpoint atom is marked full")
        collector._full.append(atom)

    for indices, u, sign, exponents, correction in payload["combined"]:
        if len(indices) != 2:
            raise ValueError("checkpoint match needs two atoms")
        selected = [take(i) for i in indices]
        item = CombinedRelation(
            tuple(a.relation_id for a in selected),
            arithmetic.backend_for(base.n).integer(u),
            sign,
            tuple(tuple(pair) for pair in exponents),
            arithmetic.backend_for(base.n).integer(correction),
        )
        scratch = (
            _combination_workspace(selected, base, config.memory_limit)
            - base.workspace_bytes
        )
        if retained_workspace + scratch > config.memory_limit:
            raise MemoryError("restored SIQS match scratch exceeds cap")
        collector._scratch_peak_bytes = max(
            collector._scratch_peak_bytes, scratch
        )
        verify_combined(
            item,
            base,
            collector._atoms,
            budget=budget,
            memory_bytes=config.memory_limit,
        )
        collector._combined.append(item)
        last = atoms[max(indices)].relation_id
        collector._atom_bytes[last] += combined_storage_reserve(
            sum(len(a.exponents) for a in selected), base.n.bit_length()
        )

    for residual, index in payload["pending"]:
        atom = take(index)
        if (
            residual != atom.residual
            or residual == 1
            or residual in collector._pending
        ):
            raise ValueError("invalid checkpoint partial matching state")

        collector._pending[residual] = atom.relation_id

    if len(used) != len(atoms):
        raise ValueError("checkpoint has unreferenced atomic provenance")
    rows = collector._full + collector._combined
    collector._rows.extend(rows[index] for index in order)
    collector._workspace += sum(collector._atom_bytes.values())


def _checkpoint_restore_config(config, blob_bytes):
    """Reserve decoded snapshot coexistence until checked restore completes."""
    if config.checkpoint_bytes is not None:
        return config
    from dataclasses import replace

    # Reuse the existing eight-representation checkpoint reservation, sized
    # from actual input rather than inventing a fixed growing-mode ceiling.
    # Empty growing-store snapshots can be smaller than the public minimum.
    return replace(config, checkpoint_bytes=max(4096, blob_bytes + 1024))


def restore_job(checkpoint, *, budget, config=None, allow_extension=False):
    """Verify and rebuild charged roots, stores and solver prefixes."""
    from .siqs import CountedSIQSConfig, SIQSConfig, SIQSJob, make_family

    if not isinstance(checkpoint, dict) or set(checkpoint) != {
        "version",
        "blob",
        "sha256",
        "resources",
        "resources_sha256",
    }:
        raise ValueError("invalid full SIQS checkpoint envelope")

    blob = checkpoint["blob"]
    if type(checkpoint["version"]) is not int or checkpoint["version"] not in (
        1,
        2,
        VERSION,
        4,
        5,
        6,
        7,
    ):
        raise ValueError("unsupported SIQS checkpoint version")

    if (
        not isinstance(blob, str)
        or (
            checkpoint["version"] < 5
            and (
                len(blob) > MAX_BLOB_BYTES
                or len(blob.encode()) > MAX_BLOB_BYTES
            )
        )
        or (
            config is not None
            and len(blob.encode()) + 1024 > config.checkpoint_limit
        )
    ):
        raise ValueError("SIQS checkpoint blob exceeds its cap")

    if config is not None and config.checkpoint_bytes is None:
        # The character count rejects oversized input before making another
        # byte copy. The exact UTF-8 size then covers non-ASCII input too.
        _checkpoint_restore_config(config, len(blob))
        _checkpoint_restore_config(config, len(blob.encode()))

    if hashlib.sha256(blob.encode()).hexdigest() != checkpoint["sha256"]:
        raise ValueError("SIQS checkpoint integrity mismatch")
    resources = _checked_resources(checkpoint["resources"])
    if _checksum(resources) != checkpoint["resources_sha256"]:
        raise ValueError("SIQS checkpoint resource integrity mismatch")
    payload = json.loads(blob)
    if type(payload["version"]) is not int or (
        payload["version"] != checkpoint["version"]
    ):
        raise ValueError("invalid SIQS checkpoint payload version")
    if payload["version"] >= 2 and payload["store"] is not None:
        if not isinstance(payload["store"], dict) or (
            "row_order" not in payload["store"]
        ):
            raise ValueError("mixed-order checkpoint lacks row_order")

    values = dict(payload["config"])
    if payload["version"] < 7 and (
        (values.get("solve_policy", "window") != "window")
        != (payload["version"] == 6)
    ):
        raise ValueError("SIQS scheduling policy disagrees with schema")
    if payload["version"] < 7 and (
        "sign_policy" in values or "sparse_queue_bytes" in values["collector"]
    ):
        raise ValueError("legacy checkpoint cannot change collection policy")
    if payload["version"] == 7 and (
        "sign_policy" not in values
        or "sparse_queue_bytes" not in values["collector"]
    ):
        raise ValueError("collection checkpoint lacks its policy identity")
    collector_type = (
        GrowingDoubleLargeSieveConfig
        if payload["version"] == 5
        or payload["version"] >= 6
        and values["collector"].get("storage_policy") == "grow"
        else DoubleLargeSieveConfig
        if payload["version"] == 4
        or payload["version"] >= 6
        and "large_prime_bound" in values["collector"]
        else SieveConfig
    )
    values["collector"] = collector_type(**values["collector"])
    config_type = CountedSIQSConfig if "base_count" in values else SIQSConfig
    saved_config = config_type(**values)
    if type(allow_extension) is not bool:
        raise TypeError("allow_extension must be Boolean")
    extended = config is not None and config != saved_config
    if extended:
        if not allow_extension:
            raise ValueError("SIQS checkpoint configuration mismatch")
        from .capacity import validate_extension

        validate_extension(saved_config, config)
    else:
        config = saved_config

    expected_backend = arithmetic.get_backend(config.backend).identity
    if (
        payload.get(
            "backend", "python-int" if payload["version"] < 3 else None
        )
        != expected_backend
    ):
        raise ValueError("incompatible checkpoint backend")

    if len(blob.encode()) + 1024 > config.checkpoint_limit:
        raise ValueError("SIQS checkpoint exceeds configured byte cap")
    if budget.work_limit < resources["work_used"]:
        raise ValueError("resume allowance is below consumed work")
    if budget.used == 0 and budget.prior_wall == 0 and budget.prior_cpu == 0:
        budget.used = resources["work_used"]
        budget.prior_wall = resources["wall_used"]
        budget.prior_cpu = resources["cpu_used"]
    elif (
        budget.used < resources["work_used"]
        or budget.wall_used < resources["wall_used"]
        or budget.cpu_used < resources["cpu_used"]
    ):
        raise ValueError("resume must retain consumed resources")

    public_config = config
    dynamic_snapshot = config.checkpoint_bytes is None
    if dynamic_snapshot:
        config = _checkpoint_restore_config(config, len(blob.encode()))
    budget.consume(0)
    job = SIQSJob(
        payload["n"], seed=payload["seed"], config=config, budget=budget
    )

    for name, limit in (
        ("epoch", config.growth_steps),
        ("family_index", config.family_count),
        ("stalled", config.polynomial_limit),
        ("poly_start_rows", config.collector.relation_limit),
    ):
        value = utils.require_integer(payload[name], name, 0)
        if value > limit:
            raise ValueError("SIQS checkpoint progress exceeds its bound")
        setattr(job, name, value)

    expected_width = min(
        config.max_half_width, config.half_width * (2**job.epoch)
    )
    if payload["half_width"] != expected_width:
        raise ValueError("SIQS checkpoint width disagrees with recovery epoch")
    job.half_width = expected_width
    for name in ("active",):
        if type(payload[name]) is not bool:
            raise ValueError("invalid SIQS checkpoint flag")
        setattr(job, name, payload[name])
    job.coefficient_cursor = utils.require_integer(
        payload.get("coefficient_cursor", 0), "coefficient cursor", 0
    )
    if job.coefficient_cursor.bit_length() > 2048:
        raise ValueError("coefficient cursor exceeds its bit limit")
    if not config.external_coefficients and job.coefficient_cursor:
        raise ValueError("nonexternal job has a coefficient cursor")
    if config.external_coefficients and job.coefficient_cursor:
        latest = payload["pending"]
        if latest is None and payload["engine"] is not None:
            latest = payload["engine"]["polynomial"]
        if (
            latest is None
            or len(latest) != 3
            or latest[2] + 4 != job.coefficient_cursor
            or latest[2] % 4 != 3
            or latest[0] != latest[2] ** 2
        ):
            raise ValueError(
                "external coefficient cursor disagrees with progress"
            )

    if config.streaming and payload["seen"]:
        raise ValueError(
            "streaming checkpoint must not contain a history registry"
        )
    if len(payload["seen"]) > config.polynomial_limit:
        raise ValueError("SIQS checkpoint registry exceeds its bound")
    job.seen = set(tuple(key) for key in payload["seen"])
    if len(job.seen) != len(payload["seen"]):
        raise ValueError("duplicate SIQS checkpoint registry entry")
    for a, b, width in job.seen:
        utils.require_integer(a, "registry A", 1)
        utils.require_integer(b, "registry B", 0)
        utils.require_integer(width, "registry width", 1)
        if (
            a.bit_length() > 4096
            or b > a // 2
            or width > config.max_half_width
        ):
            raise ValueError("invalid SIQS checkpoint polynomial registry")

    job.stats = payload["stats"]
    job.divisor = payload["divisor"]
    if job.divisor is not None and not utils.valid_divisor(job.divisor, job.n):
        raise ValueError("invalid checkpoint divisor")
    allowed = (
        None,
        "families_exhausted",
        "assignment_space_exhausted",
        "coefficient_limit",
        "stalled_yield",
        "trivial_dependency_limit",
        "relation_limit",
        "atom_limit",
        "memory_limit",
        "configuration_refusal",
    )
    if payload["finished_reason"] not in allowed:
        raise ValueError("invalid SIQS checkpoint stop reason")
    job.finished_reason = payload["finished_reason"]
    if payload["version"] >= 6:
        pending = payload["pending_final_reason"]
        if pending not in allowed or (
            pending is not None
            and (
                not config.paced_collection
                or job.finished_reason is not None
                or payload["engine"] is None
            )
        ):
            raise ValueError("invalid pending SIQS collection stop")
        job.pending_final_reason = pending
    job.multiplier = payload["multiplier"]
    if job.multiplier is not None:
        utils.require_integer(job.multiplier, "checkpoint multiplier", 1)
        if (
            config.multiplier and job.multiplier != config.multiplier
        ) or job.multiplier > 1000000:
            raise ValueError(
                "SIQS checkpoint multiplier differs from configuration"
            )

    if payload["base_identity"] is not None:
        job._setup()
        if job.base is None or _identity(job.base) != payload["base_identity"]:
            raise ValueError("SIQS checkpoint base identity mismatch")
        if (
            payload["assignment_identity"] is not None
            and assignment_identity(job.assignments)
            != payload["assignment_identity"]
        ):
            raise ValueError("SIQS checkpoint assignment identity mismatch")

        if payload["assignment_identity"] is None:
            job.assignments = None
    elif payload["engine"] is not None or payload["store"] is not None:
        raise ValueError("SIQS checkpoint store has no factor base")

    gray = payload["gray_index"]
    if gray is not None:
        if job.assignments is None or job.family_index >= len(job.assignments):
            raise ValueError("SIQS checkpoint family index is exhausted")
        family_factory = (
            partial(make_family, config=config)
            if config.sign_policy != "canonical"
            else PolynomialFamily
        )
        job.family = family_factory(
            job.base,
            job.assignments[job.family_index],
            budget=budget,
            memory_bytes=config.memory_limit - config.metadata_reserve,
        )
        utils.require_integer(gray, "Gray index", 0)
        if gray > min(job.family.count, config.gray_limit):
            raise ValueError("SIQS checkpoint Gray index exceeds its family")
        if gray:
            job.family.current = job.family._make_step(gray - 1, None)
        job.family.next_index = gray
        job.stats["root_reconstructions"] += 1

    if payload["pending"] is not None:
        polynomial = Polynomial(job.n, job.multiplier, *payload["pending"])
        if job.family is not None and (
            job.family.current is None
            or polynomial != job.family.current.polynomial
        ):
            raise ValueError(
                "SIQS checkpoint pending polynomial disagrees with family"
            )

        roots = tuple(
            polynomial_roots(polynomial, job.base, e, budget=budget)
            for e in job.base.entries
        )
        job.pending_step = (polynomial, roots)

    saved = payload["engine"]
    if saved is not None:
        polynomial = Polynomial(job.n, job.multiplier, *saved["polynomial"])
        roots = tuple(
            polynomial_roots(polynomial, job.base, e, budget=budget)
            for e in job.base.entries
        )
        extra = config.metadata_reserve + 65536 + 640 * len(job.base.entries)
        extra += 16 * (
            max(2, config.factor_count) * job.base.bound.bit_length()
            + job.n.bit_length()
        )
        from dataclasses import replace

        collector_config = replace(
            config.collector, memory_bytes=config.memory_limit - extra
        )
        job.engine = QSJob(
            polynomial,
            job.base,
            saved["lo"],
            saved["hi"],
            config=collector_config,
            budget=budget,
            weight_two=config.weight_two,
            row_excess=config.row_excess,
            batch_width=config.batch_width,
            filter_row_growth=config.filter_row_growth,
            tested_dependencies=config.tested_dependencies,
            collection_continues=config.paced_collection,
            collector_class=partial(SieveCollector, precomputed_roots=roots),
        )
        engine = job.engine
        if _checksum(payload["store"]) != payload["store_identity"]:
            raise ValueError(
                "SIQS checkpoint relation store identity mismatch"
            )
        _restore_store(payload["store"], engine.collector, budget)
        if payload["version"] >= 6:
            engine.zero_checked_count = utils.require_integer(
                saved["zero_checked_count"], "zero-row cursor", 0
            )
            if engine.zero_checked_count > len(engine.collector._rows):
                raise ValueError("zero-row cursor exceeds retained rows")
        for name in (
            "next_position",
            "last_count",
            "last_solved_count",
            "workspace_peak",
        ):
            value = utils.require_integer(
                saved[name],
                name,
                -1
                if name.startswith("last")
                else 0
                if name == "workspace_peak"
                else saved["lo"],
            )
            if name == "next_position" and value > saved["hi"]:
                raise ValueError(
                    "SIQS checkpoint block position exceeds window"
                )
            setattr(
                engine,
                "_workspace_peak" if name == "workspace_peak" else name,
                value,
            )

        for name in ("final_solve_done", "storage_solve_done"):
            if type(saved[name]) is not bool:
                raise ValueError("invalid SIQS engine completion flag")
            setattr(engine, name, saved[name])
        engine.storage_reason = saved["storage_reason"]
        if engine.storage_reason not in (
            None,
            "relation_limit",
            "atom_limit",
            "memory_limit",
        ):
            raise ValueError("invalid SIQS checkpoint storage reason")

        engine.stats = saved["stats"]
        prefix = saved["solver"]
        if prefix is not None:
            relations = engine.collector.matrix_relations
            prepared = prepare_relations(
                relations,
                job.base,
                engine.collector._atoms,
                budget=budget,
                memory_bytes=collector_config.memory_limit,
                retained_workspace_bytes=engine.collector._workspace,
                max_rows=collector_config.max_relations,
                max_atoms=collector_config.max_atoms,
            )
            live = (
                engine.collector._workspace
                + prepared.workspace_bytes
                - prepared.shared_workspace_bytes
            )
            matrix = filter_matrix(
                prepared.rows,
                weight_two=config.weight_two,
                budget=budget,
                memory_bytes=max(0, collector_config.memory_limit - live),
                max_rows=collector_config.max_relations,
            )
            solver = DependencySolver(matrix, budget=budget)
            actions = utils.require_integer(
                prefix["actions"], "solver actions", 0
            )
            if actions > resources["work_used"] or actions > len(
                matrix.rows
            ) ** 2 + len(matrix.rows):
                raise ValueError(
                    "SIQS checkpoint solver prefix exceeds consumed work"
                )

            # Rebuild from checked rows rather than trusting saved pivots.
            # Replay consumes the resumed allowance and verifies its digest.
            for _ in range(actions):
                if solver.next_row == len(matrix.rows):
                    raise ValueError(
                        "SIQS checkpoint solver prefix exceeds matrix"
                    )
                solver.step()

            if (
                prefix["pending"]
                and solver.pending is None
                and solver.next_row < len(matrix.rows)
            ):
                solver.pending = (
                    matrix.rows[solver.next_row],
                    matrix.masks[solver.next_row],
                )

            if (
                _solver_digest(
                    solver,
                    encoding=prefix.get("digest_encoding", "decimal-v1"),
                )
                != prefix["digest"]
            ):
                raise ValueError("SIQS checkpoint elimination prefix mismatch")

            engine.prepared, engine.solver = prepared, solver
            if prefix["extract_index"] is not None:
                if solver.next_row != len(matrix.rows):
                    raise ValueError(
                        "SIQS checkpoint extraction precedes elimination"
                    )
                index = utils.require_integer(
                    prefix["extract_index"], "extraction index", 0
                )
                if index > len(solver.dependencies):
                    raise ValueError(
                        "SIQS checkpoint extraction index exceeds kernels"
                    )
                engine.extractor = DependencyExtractor(
                    prepared,
                    tuple(solver.dependencies),
                    budget=budget,
                    max_dependencies=collector_config.max_relations,
                )
                # Completed trials are independently replayed and charged.
                from .extraction import extract_dependency

                for mask in solver.dependencies[:index]:
                    trial = extract_dependency(prepared, mask, budget=budget)
                    if trial.divisor is not None:
                        raise ValueError(
                            "checkpoint skipped a successful dependency"
                        )
                    engine.extractor.trials.append(trial)

                engine.extractor.next_dependency = index

            job.stats["matrix_reconstructions"] += 1

    if dynamic_snapshot:
        # Decoded input and rebuild scratch cease to be job-owned on return.
        # Keep the original public policy/identity and release only this
        # transient reservation; partials and prepared solver state stay live.
        released = config.metadata_reserve - public_config.metadata_reserve
        job.config = public_config
        if job.engine is not None:
            job.engine.config = replace(
                job.engine.config,
                memory_bytes=job.engine.config.memory_limit + released,
            )
            job.engine.collector.config = job.engine.config
        config = public_config

    if job.active and job.engine is None:
        raise ValueError("active SIQS checkpoint has no collector")
    if (extended or dynamic_snapshot) and job.base is not None:
        from .capacity import capacity_report

        job.stats["capacity"] = capacity_report(job.base, config)
    if extended and job.divisor is None:
        reasons = {
            "coefficient_limit": config.coefficient_trials
            > saved_config.coefficient_trials,
            "families_exhausted": config.family_count
            > saved_config.family_count,
            "stalled_yield": config.max_stalled > saved_config.max_stalled,
            "trivial_dependency_limit": config.max_trivial
            > saved_config.max_trivial,
            "relation_limit": config.collector.relation_limit
            > saved_config.collector.relation_limit,
            "atom_limit": config.collector.atom_limit
            > saved_config.collector.atom_limit,
            "memory_limit": config.memory_limit - config.metadata_reserve
            > saved_config.memory_limit - saved_config.metadata_reserve,
        }
        if reasons.get(job.finished_reason, False):
            job.finished_reason = None
            if job.engine is not None and reasons.get(
                job.engine.storage_reason, False
            ):
                job.engine.storage_reason = None
                job.engine.storage_solve_done = False
        if reasons.get(job.pending_final_reason, False):
            # The extended search can collect again. Any retained downstream
            # prefix still runs before the engine admits another relation.
            job.pending_final_reason = None
    return job
